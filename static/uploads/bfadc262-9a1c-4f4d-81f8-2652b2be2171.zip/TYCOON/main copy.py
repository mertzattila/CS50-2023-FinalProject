import pygame
import button
pygame.init()
# game
WIDTH, HEIGHT = 600,800
FPS = 60
win = pygame.display.set_mode((WIDTH, HEIGHT))

# colors
BLACK = (0,0,0)
WHITE = (255,255,255)
BLUE =(0,0,255)

# font
balance_font = pygame.font.SysFont("comicsans",40)



# images
#bg_img = pygame.image.load("images/bg.png").convert_alpha()
coin_img = pygame.transform.scale(pygame.image.load("images/coin.png").convert_alpha(),(50,50))
moneybg_img = pygame.image.load("images/moneybg.png").convert_alpha()


# player images
walkRight = [pygame.image.load('images/player/R1.png'), pygame.image.load('images/player/R2.png'), pygame.image.load('images/player/R3.png'), pygame.image.load('images/player/R4.png'), pygame.image.load('images/player/R5.png'), pygame.image.load('images/player/R6.png'), pygame.image.load('images/player/R7.png'), pygame.image.load('images/player/R8.png'), pygame.image.load('images/player/R9.png')]
walkLeft = [pygame.image.load('images/player/L1.png'), pygame.image.load('images/player/L2.png'), pygame.image.load('images/player/L3.png'), pygame.image.load('images/player/L4.png'), pygame.image.load('images/player/L5.png'), pygame.image.load('images/player/L6.png'), pygame.image.load('images/player/L7.png'), pygame.image.load('images/player/L8.png'), pygame.image.load('images/player/L9.png')]
char = pygame.image.load('images/player/standing.png')



    #1. floor images
f_floor_img = pygame.image.load("images/1floor.png").convert_alpha()
buyb100_img = pygame.image.load("images/buttons/100buyb.png").convert_alpha()
buys100_img = pygame.image.load("images/buttons/100buys.png").convert_alpha()
buys50_img = pygame.image.load("images/buttons/50buys.png").convert_alpha()
tomato_img = pygame.image.load("images/tomato.png").convert_alpha()
carrot_img = pygame.image.load("images/carrot.png").convert_alpha()


    #2. floor images
s_floor_img = pygame.image.load("images/1floor.png").convert_alpha()
buyb1000_img = pygame.image.load("images/buttons/1000buyb.png").convert_alpha()


# buttons

    #1. floor button
f_floor_button = button.Button(WIDTH - WIDTH/6*2 - buyb100_img.get_width(),HEIGHT- HEIGHT/8- buyb100_img.get_height(),buyb100_img,1)
tomato_button = button.Button(WIDTH- WIDTH/2,HEIGHT- tomato_img.get_height()-75,buys50_img,1)
carrot_button = button.Button(WIDTH- WIDTH/2- 125,HEIGHT- tomato_img.get_height()-75,buys100_img,1)

    #2. floor button
s_floor_button = button.Button(WIDTH - WIDTH/6*2 - buyb1000_img.get_width(),HEIGHT- HEIGHT/3- buyb1000_img.get_height(),buyb1000_img,1)


# player
class PLAYER:
    VEL = 2
    JUMP = False
    JumpCount = 10

    left = False
    right = False
    walkCount = 0
    def __init__(self,x,y,width,height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
    def draw(self,win):
        if self.walkCount + 1 >= 90:
            self.walkCount = 0
             
        if self.left:
            self.draw_left = pygame.transform.scale(walkLeft[self.walkCount//10],(self.width,self.height))
            win.blit(self.draw_left,(self.x,self.y))
            self.walkCount += 1
        elif self.right:
            self.draw_right = pygame.transform.scale(walkRight[self.walkCount//10],(self.width,self.height))
            win.blit(self.draw_right,(self.x,self.y)) 
            self.walkCount += 1
        else:
            self.draw_char = pygame.transform.scale(char,(self.width,self.height))
            win.blit(self.draw_char,(self.x,self.y))

        
    
    def move(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_d]and self.x + self.width < WIDTH:# right
            self.x += self.VEL
            self.right = True
            self.left= False
        elif keys[pygame.K_a] and self.x > 0:# left
            self.x -= self.VEL
            self.right = False
            self.left = True
        else:
            self.right = False
            self.left = False
            self.walkCount = 0
        if not(self.JUMP):
            if keys[pygame.K_SPACE]:
                self.JUMP = True
                self.right = False
                self.left = False
                self.walkCount = 0
        else:
            if self.JumpCount >= -10:
                self.neg = 1
                if self.JumpCount<0:
                    self.neg = -1
                self.y -= self.JumpCount**2 /2 *self.neg
                self.JumpCount -= 1
            else:
                self.JUMP = False
                self.JumpCount = 10














# game draw function
def draw(balance_text,f_floor_state, s_floor_state,tomato_state,carrot_state):
    # bg
    #win.blit(bg_img,(0,0))
    win.fill(BLUE)
    
    # money
    #win.blit(moneybg_img,(WIDTH - moneybg_img.get_width()- coin_img.get_width(), 0))
    win.blit(coin_img,(WIDTH - coin_img.get_width(),0))
    win.blit(balance_text,(WIDTH - coin_img.get_width()- balance_text.get_width(),-5))
    
    # floors
    
        # 1. floor
    if f_floor_state:    
        win.blit(f_floor_img,(WIDTH/6, HEIGHT - f_floor_img.get_height()))
        if tomato_state:
            win.blit(tomato_img,(WIDTH- WIDTH/2,HEIGHT- tomato_img.get_height()-75))
        if carrot_state:
            win.blit(carrot_img,(WIDTH- WIDTH/2- 125,HEIGHT- tomato_img.get_height()-75))
        
        #2. floor
    if s_floor_state:
        pass



# main function
def main():
    # balance var
    balance = 10000
    balance_add = 0
    counter = 0
    
    # game
    clock = pygame.time.Clock()
    run = True
    
    # floors
    f_floor_state, s_floor_state, tomato_state, carrot_state = False, False, False, False
    f_floor_uc, s_floor_uc = 100, 1000
    tomato_c = 50
    carrot_c = 100
    
    p_height = 128
    p_width = 128
    p_y = HEIGHT - p_height
    p_x = WIDTH/2
    player = PLAYER(p_x,p_y,p_width,p_height)
    
    while run:
            
        
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                run = False
                
        player.move()

        # balance
        balance_text = balance_font.render(str(balance),1,BLACK)
        counter += 1
        if counter % FPS == 0:
            balance += balance_add


   
        # game draw
        draw(balance_text,f_floor_state,s_floor_state,tomato_state,carrot_state)
        
        # floors 
        
            # 1.floor
        if f_floor_state == False:
            if f_floor_button.draw(win):
                if balance >= f_floor_uc:
                    balance -= f_floor_uc
                    f_floor_state = True
                    balance_add += 1

            
            
            # tomato
        if f_floor_state and tomato_state == False:
            if tomato_button.draw(win):
                if balance >= tomato_c:
                    tomato_state = True
                    balance -= tomato_c
                    balance_add += 5

            #carrot
        if f_floor_state and carrot_state == False:
            if carrot_button.draw(win):
                carrot_state = True
                balance -= carrot_c
                balance_add += 10
                    
                    
                    
                
            # 2.floor     
        if s_floor_state == False:
            if s_floor_button.draw(win):
                if balance >= s_floor_uc:
                    balance -= s_floor_uc
                    s_floor_state = True
                    balance_add += 10
                
        player.draw(win)
        
        pygame.display.update()
main()