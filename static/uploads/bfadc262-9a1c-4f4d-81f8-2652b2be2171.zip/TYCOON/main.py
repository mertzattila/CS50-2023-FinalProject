import pygame
import button
pygame.init()
# game
WIDTH, HEIGHT = 600,800
FPS = 60
win = pygame.display.set_mode((WIDTH, HEIGHT))

# colors
BLACK = (0,0,0)
WHITE = (255,255,255)


# font
balance_font = pygame.font.SysFont("comicsans",40)



# images
bg_img = pygame.image.load("images/bg.png").convert_alpha()
coin_img = pygame.transform.scale(pygame.image.load("images/coin.png").convert_alpha(),(50,50))
moneybg_img = pygame.image.load("images/moneybg.png").convert_alpha()

    #1. floor images
f_floor_img = pygame.image.load("images/1floor.png").convert_alpha()
buyb100_img = pygame.image.load("images/buttons/100buyb.png").convert_alpha()
buys100_img = pygame.image.load("images/buttons/100buys.png").convert_alpha()
buys50_img = pygame.image.load("images/buttons/50buys.png").convert_alpha()
tomato_img = pygame.image.load("images/tomato.png").convert_alpha()
carrot_img = pygame.image.load("images/carrot.png").convert_alpha()


    #2. floor images
s_floor_img = pygame.image.load("images/1floor.png").convert_alpha()
buyb1000_img = pygame.image.load("images/buttons/1000buyb.png").convert_alpha()


# buttons

    #1. floor button
f_floor_button = button.Button(WIDTH - WIDTH/6*2 - buyb100_img.get_width(),HEIGHT- HEIGHT/8- buyb100_img.get_height(),buyb100_img,1)
tomato_button = button.Button(WIDTH- WIDTH/2,HEIGHT- tomato_img.get_height()-100,buys50_img,1)
carrot_button = button.Button(WIDTH- WIDTH/2- 50,HEIGHT- tomato_img.get_height()-100,buys100_img,1)

    #2. floor button
s_floor_button = button.Button(WIDTH - WIDTH/6*2 - buyb1000_img.get_width(),HEIGHT- HEIGHT/3- buyb1000_img.get_height(),buyb1000_img,1)

# game draw function
def draw(balance_text,f_floor_state, s_floor_state,tomato_state,carrot_state):
    # bg
    win.blit(bg_img,(0,0))
    
    # money
    #win.blit(moneybg_img,(WIDTH - moneybg_img.get_width()- coin_img.get_width(), 0))
    win.blit(coin_img,(WIDTH - coin_img.get_width(),0))
    win.blit(balance_text,(WIDTH - coin_img.get_width()- balance_text.get_width(),-5))
    
    # floors
    
        # 1. floor
    if f_floor_state:    
        win.blit(f_floor_img,(WIDTH/6, HEIGHT - f_floor_img.get_height()))
        if tomato_state:
            win.blit(tomato_img,(WIDTH- WIDTH/2,HEIGHT- tomato_img.get_height()-100))
        if carrot_state:
            win.blit(carrot_img,(WIDTH- WIDTH/2- 50,HEIGHT- tomato_img.get_height()-100))
        
        #2. floor
    if s_floor_state:
        pass



# main function
def main():
    # balance var
    balance = 1000
    balance_add = 0
    counter = 0
    
    # game
    clock = pygame.time.Clock()
    run = True
    
    # floors
    f_floor_state, s_floor_state, tomato_state, carrot_state = False, False, False, False
    f_floor_uc, s_floor_uc = 100, 1000
    tomato_c = 50
    carrot_c = 100
    
    
    while run:
            
        
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                run = False
                

        # balance
        balance_text = balance_font.render(str(balance),1,BLACK)
        counter += 1
        if counter % FPS == 0:
            balance += balance_add


   
        # game draw
        draw(balance_text,f_floor_state,s_floor_state,tomato_state,carrot_state)
        
        # floors 
        
            # 1.floor
        if f_floor_state == False:
            if f_floor_button.draw(win):
                if balance >= f_floor_uc:
                    balance -= f_floor_uc
                    f_floor_state = True
                    balance_add += 1

            
            
            # tomato
        if f_floor_state and tomato_state == False:
            if tomato_button.draw(win):
                if balance >= tomato_c:
                    tomato_state = True
                    balance -= tomato_c
                    balance_add += 5

            #carrot
        if f_floor_state and carrot_state == False:
            if carrot_button.draw(win):
                carrot_state = True
                balance -= carrot_c
                balance_add += 10
                    
                    
                    
                
            # 2.floor     
        if s_floor_state == False:
            if s_floor_button.draw(win):
                if balance >= s_floor_uc:
                    balance -= s_floor_uc
                    s_floor_state = True
                    balance_add += 10
                
        pygame.display.update()
main()