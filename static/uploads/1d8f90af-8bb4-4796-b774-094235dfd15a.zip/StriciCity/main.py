import asyncio
import pygame



pygame.init()
# colors
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
BLACK= (0,0,0)
WHITE= (255,255,255)
PURPLE = (255,0,255)
# images
icon = pygame.image.load("icon.png")
coin = pygame.image.load("coin.png")
castle = pygame.transform.scale(pygame.image.load("castle.png"), (250,250))
falu = pygame.transform.scale(pygame.image.load("falu.png"), (300,300))
farm = pygame.transform.scale(pygame.image.load("farm.png"), (300,300))
SmallCity = pygame.transform.scale(pygame.image.load("test.png"), (300,300))
ModernHouse = pygame.transform.scale(pygame.image.load("test.png"), (300,300))




# display
WIDTH, HEIGHT = 1000,800
win = pygame.display.set_mode((WIDTH,HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("StriciCity")
pygame.display.set_icon(icon)

#  Font
MONEY_FONT = pygame.font.SysFont('comicsans', 40)
BUTTON_FONT = pygame.font.SysFont('comicsans', 20)
TITLE = pygame.font.SysFont('comicsans', 50)

# global variables
FPS = 60
Castle_Spawn = pygame.USEREVENT + 1
Falu_Spawn = pygame.USEREVENT + 2
Farm_Spawn = pygame.USEREVENT + 3
SmallCity_Spawn = pygame.USEREVENT + 4
ModernHouse_Spawn = pygame.USEREVENT + 5

# main game
                    
def get_background(name):
    image = pygame.image.load(name)
    _,_, width, height = image.get_rect()
    tiles = []

    for i in range(WIDTH // width + 1):
        for j in range(HEIGHT // height +1):
            pos = (i * width, j *height)
            tiles.append(pos)

    return tiles,image


            
            
            
def draw(background, bg_image, money_text, Button_falu,button1,Button_Farm,button2,Button_SmallCity,button3,button4,Button_ModernCity,check1,check2,check3,check4,upgrade0,upgrade1,upgrade2,upgrade3,upgrade4,Title):

    for title in background:
        win.blit(bg_image, title)
    win.blit(money_text, (WIDTH-bg_image.get_width()-125, 30))
    win.blit(coin,(WIDTH-bg_image.get_width(),30))
    win.blit(Title,(500-Title.get_width()/2,20))
    # 1
    if check1 == False:
        pygame.draw.rect(win, GREEN,button1,)
        win.blit(Button_falu, (300,700))
    # 2
    if check2 == False:
        pygame.draw.rect(win, GREEN,button2,)
        win.blit(Button_Farm, (700,700))        
    # 3
    if check3 == False:
        pygame.draw.rect(win, GREEN,button3,)
        win.blit(Button_SmallCity, (200,200)) 
    # 4
    if check4 == False:
        pygame.draw.rect(win, GREEN,button4,)
        win.blit(Button_ModernCity, (600,200))
    win.blit(castle,(10,500))
    win.blit(upgrade0,(10,750))
    if check1:
        win.blit(falu,(350,450))
        win.blit(upgrade1, (300 + 150/2, 750))
    if check2:
        win.blit(farm, (700,500))
        win.blit(upgrade2,(800-50,700))
    if check3:
        pass
    if check4:
        pass
    
    pygame.display.update()




async def main():
    money = 1000
    counter = 0
    upgrade_cost0 = 1
    upgrade_cost1 = 1
    upgrade_cost2 = 1
    upgrade_cost3 = 1
    upgrade_cost4 = 1
    check1 = False
    check2 = False
    check3 = False
    check4 = False
    Title = TITLE.render("STRICICTY", 1,BLUE)
    background, bg_image = get_background("Green.png")
    clock = pygame.time.Clock()
    Button_Falu = BUTTON_FONT.render("1000-COIN TO BUY FALU",1,BLACK)
    button1 = pygame.Rect(300,700,Button_Falu.get_width()+2,Button_Falu.get_height()+2)
    Button_Farm = BUTTON_FONT.render("2000-COIN TO BUY FARM", 1, BLACK)
    button2 = pygame.Rect(700,700,Button_Farm.get_width()+2, Button_Farm.get_height()+ 2)
    Button_SmallCity = BUTTON_FONT.render("4000-COIN TO BUY SMALLCITY", 1, BLACK)
    button3 = pygame.Rect(200,200,Button_SmallCity.get_width()+2, Button_SmallCity.get_height()+ 2)
    Button_ModernCity = BUTTON_FONT.render("8000-COIN TO BUY MODERNCITY", 1, BLACK)
    button4 = pygame.Rect(600,200,Button_ModernCity.get_width()+2, Button_ModernCity.get_height()+ 2)
    run = True
    add_money0 = 1
    add_money1 = 1
    add_money2 = 1
    add_money3 = 1
    add_money4 = 1
    while run:
        upgrade0 = MONEY_FONT.render("UPGRADE "+ str(upgrade_cost0), 1,BLACK)
        upgrade1 = MONEY_FONT.render("UPGRADE "+ str(upgrade_cost1), 1,BLACK)
        upgrade2 = MONEY_FONT.render("UPGRADE "+ str(upgrade_cost2), 1,BLACK)
        upgrade3 = MONEY_FONT.render("UPGRADE "+ str(upgrade_cost3), 1,BLACK)
        upgrade4 = MONEY_FONT.render("UPGRADE "+ str(upgrade_cost4), 1,BLACK)
        m_x,m_y = pygame.mouse.get_pos()
        clock.tick(FPS)
        counter += 1
        if counter % 60 == 0:
            money += add_money0
            money += add_money1
            money += add_money2
            money += add_money3
            money += add_money4
        money_text = MONEY_FONT.render(str(money), 1 ,BLACK)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
            

            if event.type == pygame.MOUSEBUTTONDOWN:
                if check1 == False:
                    if m_x < 300+Button_Falu.get_width() and m_x > 300 and m_y < 700+Button_Falu.get_height() and m_y >700:
                        if money >= 1000:
                            money -= 1000
                            check1 = True

                if check2 == False:       
                    if m_x < 700+Button_Falu.get_width() and m_x > 700 and m_y < 700+Button_Falu.get_height() and m_y >700:
                        if money >= 2000:
                            money -= 2000
                            check2 = True

                if check3 == False:        
                    if m_x < 200+Button_Falu.get_width() and m_x > 200 and m_y < 200+Button_Falu.get_height() and m_y >200:
                        if money >= 4000:
                            money -= 4000
                            check3 = True
                if check4 == False:      
                    if m_x < 600+Button_Falu.get_width() and m_x > 600 and m_y < 200+Button_Falu.get_height() and m_y >200:
                        if money >= 8000:
                            money -= 8000
                            check4 = True

                if m_x < 10 + upgrade0.get_width() and m_x > 10 and m_y < 750+upgrade0.get_height() and m_y >750:
                    if money >= upgrade_cost0:
                            money -= upgrade_cost0
                            upgrade_cost0 *= 2
                            add_money0 = 10
                            if upgrade_cost0 >300:
                                add_money0 = 20
                            elif upgrade_cost0 >1000:
                                add_money0 = 30
                if check1 == True:
                    if m_x < 300 + 150/2 + upgrade1.get_width() and m_x > 300 + 150/2 and m_y < 750+upgrade1.get_height() and m_y >750:
                        if money >= upgrade_cost1:
                            money -= upgrade_cost1
                            upgrade_cost1 *= 2
                            add_money1 = 10
                            if upgrade_cost1 >300:
                                add_money1 = 20
                            elif upgrade_cost1 >1000:
                                add_money1 = 30

                if check2 == True:
                    if m_x < 750 + upgrade2.get_width() and m_x > 750 and m_y < 700+upgrade2.get_height() and m_y >700:
                        if money >= upgrade_cost2:
                            money -= upgrade_cost2
                            upgrade_cost2 *= 2
                            add_money2 = 10
                            if upgrade_cost2 >300:
                                add_money2 = 20
                            elif upgrade_cost2 >1000:
                                add_money2 = 30

                if check3 == True:
                    if m_x < 300 + 150/2 + upgrade3.get_width() and m_x > 300 + 150/2 and m_y < 750+upgrade3.get_height() and m_y >750:
                        if money >= upgrade_cost3:
                            money -= upgrade_cost3
                            upgrade_cost3 *= 2
                            add_money3 = 10
                            if upgrade_cost3 >300:
                                add_money3 = 20
                            elif upgrade_cost3 >1000:
                                add_money3 = 30

                if check4 == True:
                    if m_x < 300 + 150/2 + upgrade4.get_width() and m_x > 300 + 150/2 and m_y < 750+upgrade4.get_height() and m_y >750:
                        if money >= upgrade_cost4:
                            money -= upgrade_cost4
                            upgrade_cost4 *= 2
                            add_money4 = 10
                            if upgrade_cost4 >300:
                                add_money4 = 20
                            elif upgrade_cost4 >1000:
                                add_money4 = 30
                        
                

        draw(background, bg_image, money_text, Button_Falu,button1,Button_Farm, button2, Button_SmallCity,button3,button4,Button_ModernCity,check1,check2,check3,check4,upgrade0,upgrade1,upgrade2,upgrade3,upgrade4,Title)
        await asyncio.sleep(0)

        
asyncio.run(main())
