import random
def main():
    
    user_choice = str(input(""))
    Moves = ["Rock", "Papper", "Scissors"]
    Computer_choice = random.choice(Moves)
    while True:
        if user_choice not in Moves:
                print("Wrong Item")
                user_choice = str(input())
        if user_choice in Moves:
            break
    print("Your choice: "+ user_choice)
    print("Computer choice: " + Computer_choice)
    if Computer_choice == user_choice:
        print("Draw")
        
    if user_choice == "Rock" and Computer_choice == "Papper" or user_choice == "Papper" and Computer_choice == "Scissors" or user_choice == "Scissors" and Computer_choice == "Rock":
        print("You Lost")
        
    if user_choice == "Rock" and Computer_choice == "Scissors" or user_choice == "Papper" and Computer_choice == "Rock" or user_choice == "Scissors" and Computer_choice == "Papper":
        print("You Won")
     
while True:
    
    main()
    stopit = input("Write stop to stop")
    if stopit == "stop":
        print("Programm stopped")
        break
