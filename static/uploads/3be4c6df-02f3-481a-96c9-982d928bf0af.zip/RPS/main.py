import pygame
import math
import random
pygame.init()
# WIN Width, Height
WIDTH, HEIGHT = 900, 500


# COLORS
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)


# images
icon = pygame.image.load("icon.png")
BG = pygame.transform.scale(pygame.image.load("bg.png"),(900,500))

# display
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Rock,Papper,Scissors")
pygame.display.set_icon(icon)
RADIUS = 40

# Font
Choice_Font = pygame.font.SysFont('comicsans', 20)
End_Font = pygame.font.SysFont('comicsans', 60)


def main():
    Moves = ["Rock", "Papper", "Scissors"]
    Computer_choice = random.choice(Moves)
    run = True
    rock = Choice_Font.render("ROCK",1 , BLACK)
    papper = Choice_Font.render("PAPPER",1 , BLACK)
    scissors = Choice_Font.render("SCISS",1 , BLACK)
    your_choice = Choice_Font.render("Your Choice",1 , BLACK)
    computer_choice = Choice_Font.render("Computer Choice",1 , BLACK)
    computer_item_choice = Choice_Font.render(Computer_choice,1 , BLACK)
    win1 = End_Font.render("YOU WON", 1, GREEN)
    loose = End_Font.render("YOU LOST", 1, RED)
    draw = End_Font.render("DRAW", 1, BLUE)
    display1 = False
    display2 = False
    display3 = False
    display4 = False
    display5 = False
    display6 = False

    while run:
        win.blit(BG, (0,0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run == False
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                m_x, m_y = pygame.mouse.get_pos()
                dis_rock = math.sqrt(((100 + 25)- m_x)**2 + ((400+ 20)-m_y)**2)
                dis_papper = math.sqrt(((100+ rock.get_width() + 50+ 25)- m_x)**2 + ((400+ 20)-m_y)**2)
                dis_scissors = math.sqrt(((100+ rock.get_width() + 50+ papper.get_width()+ 50 + 25)- m_x)**2 + ((400+ 20)-m_y)**2)
                if dis_rock < RADIUS:
                    display1 = True
                if dis_papper < RADIUS:
                    display2 = True
                if dis_scissors < RADIUS:
                    display3 = True
                if dis_rock < RADIUS and Computer_choice == "Papper" or dis_papper< RADIUS and Computer_choice == "Scissors" or dis_scissors < RADIUS and Computer_choice == "Rock":
                    display4 = True
                if dis_rock < RADIUS and Computer_choice == "Scissors" or dis_papper< RADIUS and Computer_choice == "Rock" or dis_scissors < RADIUS and Computer_choice == "Papper":
                    display5 = True
                if dis_rock < RADIUS and Computer_choice == "Rock" or dis_papper< RADIUS and Computer_choice == "Papper" or dis_scissors < RADIUS and Computer_choice == "Scissors":
                    display6 = True
        
        if display1:
            win.blit(rock,(WIDTH/2 -100 -your_choice.get_width(), 200))
            
        if display2:
            win.blit(papper,(WIDTH/2 -100 -your_choice.get_width(), 200))
            
        if display3:
            win.blit(scissors, (WIDTH/2 -100 -your_choice.get_width(),200))
        if display4:
            win.blit(computer_item_choice, (WIDTH/2  +100 , 200))
            win.blit(win1, (450- win1.get_width()/2, 250))
            pygame.display.update()         
            pygame.time.delay(3000)
            break
        if display5:
            win.blit(computer_item_choice, (WIDTH/2  +100 , 200))
            win.blit(loose, (450- loose.get_width()/2,250))
            pygame.display.update()
            pygame.time.delay(3000)
            break
        if display6:
            win.blit(computer_item_choice, (WIDTH/2  +100 , 200))
            win.blit(draw, (450- draw.get_width()/2,250))
            pygame.display.update()
            pygame.time.delay(3000)
            break
        win.blit(your_choice, (WIDTH/2 -100 -your_choice.get_width(), 100))
        win.blit(computer_choice, (WIDTH/2  +100 , 100))
        win.blit(rock, (100,400))
        win.blit(papper, (100+ rock.get_width() + 50,400))
        win.blit(scissors, (100+ rock.get_width() + 50+ papper.get_width()+ 50,400))
        pygame.draw.circle(win, RED, (100 + 25,400+ 20), RADIUS, 3)
        pygame.draw.circle(win, BLUE, (100+ rock.get_width() + 50 + 35,400+ 20), RADIUS, 3)
        pygame.draw.circle(win, GREEN, (100+ rock.get_width() + 50+ papper.get_width()+ 50 + 30,400+ 20), RADIUS, 3)
        pygame.display.update()
        
main()
